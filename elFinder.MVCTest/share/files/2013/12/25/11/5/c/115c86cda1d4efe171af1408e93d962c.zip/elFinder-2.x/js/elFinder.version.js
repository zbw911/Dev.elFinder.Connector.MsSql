/**
 * Application version
 *
 * @type String
 **/
elFinder.prototype.version = '2.0.2';

